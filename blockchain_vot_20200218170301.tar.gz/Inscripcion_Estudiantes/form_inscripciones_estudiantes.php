<?php 
  include_once('../Inscripcion_Estudiantes/index.php'); 
?> 
