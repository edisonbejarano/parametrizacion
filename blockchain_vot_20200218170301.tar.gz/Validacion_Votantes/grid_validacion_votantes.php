<?php 
  include_once('../Validacion_Votantes/index.php'); 
?> 
